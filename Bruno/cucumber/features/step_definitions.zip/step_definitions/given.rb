Then(/^I have \$(100|250) in my account$/) do |arg1|
  pending # Write code here that turns the phrase above into concrete actions
end