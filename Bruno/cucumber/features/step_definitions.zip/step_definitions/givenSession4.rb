
Given(/^I select "(Sing in|Create an account|login with facebook)"$/) do |arg|
  pending # Write code here that turns the phrase above into concrete actions
end


When(/I fill the "(username|password)" as "(Bruno|1234)"$/) do |arg|
  pending # Write code here that turns the phrase above into concrete actions
end

Then(/I got into to the "(App manager aplication)"$/) do |arg|
  pending # Write code here that turns the phrase above into concrete actions
end